declare module "@salesforce/apex/RelatedObjectRecordsController.getRelatedRecords" {
  export default function getRelatedRecords(param: {parentRecordId: any, childObjectApiName: any, relationshipFieldName: any, fieldSetName: any}): Promise<any>;
}
